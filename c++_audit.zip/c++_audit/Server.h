#pragma once
#include "general.h"
#include <fstream>
class Server
{
public:
	uint8_t* prove(uint8_t Key[16]);
	uint8_t* sample_prove(uint8_t key[16],uint8_t index[16]);
	char name[20];
	Server(std::string name);
};

